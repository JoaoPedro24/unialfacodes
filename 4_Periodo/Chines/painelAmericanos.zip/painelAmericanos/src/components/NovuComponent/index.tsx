export const NovuComponent = () => {
    return(
        <h1>Novu component</h1>
    )
} 
import { Rotas } from "./routes"
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {

  return (
  <>
    <Rotas />
  </>
  )
}

//mobiel
const styles2 = StyleSheet

export default App
